# coding: utf-8
import sqlite3
connection = sqlite3.connect('books.db')
import pandas as pd
pd.options.display.max_columns = 10
pd.read_sql("""SELECT last FROM authors ORDER BY last DESC""", connection)
pd.read_sql("""SELECT title FROM titles ORDER BY title ASC""", connection)
pd.read_sql("""SELECT title, copyright, ISBN
FROM authors
INNER JOIN titles ORDER BY title""", connection)
cursor = connection.cursor()
Cursor = cursor.execute("""INSERT INTO authors (first, last) VALUES ('Bart', 'Bielski')""")
pd.read_sql('SELECT id, first, last FROM authors', connection, index_col=['id'])
Cursor = cursor.execute("""INSERT INTO titles (isbn, title, edition, copyright)
VALUES ('01632', 'Barts Book', 1, '2021')""")
Cursor = cursor.execute("""INSERT INTO author_ISBN (isbn, id)
VALUES ('01632', 'Barts id')""")
pd.read_sql('SELECT isbn, title FROM titles ORDER BY isbn', connection)
pd.read_sql('SELECT isbn, id FROM author_ISBN ORDER BY id DESC', connection)
Cursor = cursor.execute("""UPDATE author_ISBN SET id=6""")
Cursor = cursor.execute("""UPDATE author_ISBN SET id=6WHERE las""")
Cursor = cursor.execute("""UPDATE author_ISBN SET id=6 WHERE id='Barts id' AND isbn=01632""")
pd.read_sql('SELECT isbn, id FROM author_ISBN ORDER BY id DESC', connection)
Cursor = cursor.execute("""UPDATE author_ISBN SET id=6 WHERE id='Barts id' AND isbn='01632'""")
pd.read_sql('SELECT isbn, id FROM author_ISBN ORDER BY id DESC', connection)
get_ipython().run_line_magic('save', '17.1exercise 1-99')
